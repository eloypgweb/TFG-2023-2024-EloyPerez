This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-festival/

Introducing Super Festival: A Groovy Blast from the Past

Super Festival is a font that captures the vibrant energy and nostalgia of the retro era. It blends the coolness of groovy fonts with the boldness of boxy typography, creating a unique look that’s perfect for eye-catching designs.